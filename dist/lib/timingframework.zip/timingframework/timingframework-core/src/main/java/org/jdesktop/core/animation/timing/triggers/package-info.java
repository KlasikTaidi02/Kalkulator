/**
 * A simple mechanism for starting animations when specific events occur.
 */
package org.jdesktop.core.animation.timing.triggers;