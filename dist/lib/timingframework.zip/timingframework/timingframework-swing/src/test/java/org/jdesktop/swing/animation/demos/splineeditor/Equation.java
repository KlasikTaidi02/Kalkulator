package org.jdesktop.swing.animation.demos.splineeditor;

public interface Equation {
  public double compute(double variable);
}
