/**
 * Evaluator implementations for the several useful Swing and Java2D types.
 */
package org.jdesktop.swing.animation.timing.evaluators;