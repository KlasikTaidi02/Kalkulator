/**
 * Timing source implementation for the Swing timer.
 */
package org.jdesktop.swing.animation.timing.sources;