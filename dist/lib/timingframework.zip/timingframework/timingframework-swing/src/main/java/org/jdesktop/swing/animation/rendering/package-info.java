/**
 * A flexible implementation of rendering on a Swing component that supports
 * both passive and active rendering approaches.
 */
package org.jdesktop.swing.animation.rendering;