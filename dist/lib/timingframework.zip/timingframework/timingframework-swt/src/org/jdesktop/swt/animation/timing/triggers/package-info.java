/**
 * A simple mechanism for starting animations when specific SWT events occur.
 */
package org.jdesktop.swt.animation.timing.triggers;