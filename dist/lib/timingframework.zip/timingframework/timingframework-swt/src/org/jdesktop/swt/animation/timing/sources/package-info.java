/**
 * Timing source implementation for the SWT timer.
 */
package org.jdesktop.swt.animation.timing.sources;